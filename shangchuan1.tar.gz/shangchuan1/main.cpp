#include <ros/ros.h>
#include <sensor_msgs/LaserScan.h>
#include <std_msgs/String.h>
#include <iostream>
#include "dataio.h"
#include "dtmatch.h"

using namespace cv;

std::vector<P> point2d;
void recLaserscan(const sensor_msgs::LaserScan::ConstPtr& scan_msg)
{
    unsigned int n = scan_msg->ranges.size();

    point2d.clear();
    for (unsigned int i = 0; i < n; i++)
    {
      // calculate position in laser frame

      double r = scan_msg->ranges[i];

      if (r > scan_msg->range_min && r < scan_msg->range_max)
      {
        // fill in laser scan data

        ldp->valid[i] = 1;
        ldp->readings[i] = r;
      }
      else
      {
        ldp->valid[i] = 0;
        ldp->readings[i] = -1;  // for invalid range
      }

      ldp->theta[i]    = scan_msg->angle_min + i * scan_msg->angle_increment;

      ldp->cluster[i]  = -1;
      if(ldp->readings[i]!= -1)
      {
        P pp;
        pp.x = ldp->readings[i] * cos(ldp->theta[i])/0.05;
        pp.y = ldp->readings[i] * sin(ldp->theta[i])/0.05;
        point2d.push_back(pp);
        ROS_INFO("*********x=%lf,y=%lf**********",pp.x,pp.y);
      }
    }
    std::ofstream result;
          result.open("/home/siasun/Desktop/地图激光数据/数据二/xy.txt");
          for (int i=0;i<point2d.size();i++)
          {
                  result<<point2d[i].x<<" "<<point2d[i].y<<std::endl;
          }
          result.close();

}


Mat InitPos()
{
    DataIO ref;
    string filepath1 = "Ref.txt";
    ref.readData(filepath1);

    DataIO scan;
    string filepath2 = "xy1.txt";
    scan.readData(filepath2);

    DTMatch task;
    task.loadMapPts(ref.m_inputData);
    task.loadScanPts(scan.m_inputData);

    task.generateDTMap();

    task.downsampleDTMap();

    double initPos[3] = {0.0,0.0,0.0};
    double angleRange[2] = {-180.0,180.0};
    task.setInitPos(initPos);
    task.setAngleRange(angleRange);

    Mat initPos = task.getInitPos();
    return initPos;

}


using namespace std;
using namespace cv;



int main()
{
    ros::init(argc, argv, "InitPos");
    
    ros::NodeHandle nh;

    ros::Publisher initPos_pub = n.advertise<std_msgs::String>("initPos", 100);
    ros::Subscriber initPos_sub = n.subscribe<sensor_msgs::LaserScan>("scan", 100,&recLaserscan);

    Mat initPos = InitPos();

    std_msgs::String msg;
 
    std::stringstream ss;
    ss << initPos.at<double>(0) << "," << 
          initPos.at<double>(1) << "," << initPos.at<double>(2)
    msg.data = ss.str();
 
    ROS_INFO("%s", msg.data.c_str());

    initPos_pub.publish(msg);

    ros::spinOnce();    

    return 0;
}
